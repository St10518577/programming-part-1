/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package za.ac.main;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    // TEST MESSAGE ID
    @Test
    public void testCheckMessageID_Valid() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello there"
        );

        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testCheckMessageID_Invalid() {

        Message msg = new Message(
                "12345",
                "+27831234",
                "Hello there"
        );

        assertFalse(msg.checkMessageID());
    }

    // TEST RECIPIENT NUMBER
    @Test
    public void testCheckRecipientCell_Valid() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello there"
        );

        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_Invalid() {

        Message msg = new Message(
                "1234567890",
                "0831234567",
                "Hello there"
        );

        assertFalse(msg.checkRecipientCell());
    }

    // TEST MESSAGE HASH
    @Test
    public void testCreateMessageHash() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hi Mike"
        );

        String expected =
                "12:"
                + Message.returnTotalMessages()
                + ":HIMIKE";

        assertEquals(expected, msg.createMessageHash());
    }

    // TEST SEND MESSAGE
    @Test
    public void testSentMessage_Sent() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello"
        );

        assertEquals(
                "Message successfully sent.",
                msg.sentMessage(1)
        );
    }

    @Test
    public void testSentMessage_Disregarded() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello"
        );

        assertEquals(
                "Message disregarded.",
                msg.sentMessage(2)
        );
    }

    @Test
    public void testSentMessage_Stored() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello"
        );

        assertEquals(
                "Message stored successfully.",
                msg.sentMessage(3)
        );
    }

    @Test
    public void testSentMessage_InvalidOption() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello"
        );

        assertEquals(
                "Invalid option.",
                msg.sentMessage(5)
        );
    }

    // TEST TOTAL MESSAGES
    @Test
    public void testReturnTotalMessages() {

        Message msg1 = new Message(
                "1234567890",
                "+27831234",
                "Hello"
        );

        Message msg2 = new Message(
                "0987654321",
                "+27839876",
                "Hi there"
        );

        msg1.sentMessage(1);
        msg2.sentMessage(1);

        assertEquals(2, Message.returnTotalMessages());
    }

    // TEST PRINT MESSAGE
    @Test
    public void testPrintMessages() {

        Message msg = new Message(
                "1234567890",
                "+27831234",
                "Hello World"
        );

        msg.createMessageHash();

        String expected =
                "Message ID: 1234567890"
                + "\nRecipient: +27831234"
                + "\nMessage: Hello World"
                + "\nHash: "
                + msg.createMessageHash();

        assertEquals(expected, msg.printMessages());
    }
}