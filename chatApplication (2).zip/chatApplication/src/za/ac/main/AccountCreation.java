/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package za.ac.main;


import java.util.Scanner;
import za.ac.model.Account;

public class AccountCreation {

    public static void main(String[] args) {
       System.out.println("\n===menue===");
       System.out.println("1. Register");
       System.out.println("2. Login");
       System.out.println("3. Exit");
       System.out.print("Chppse an option");
       
     
        Scanner input = new Scanner(System.in);

        System.out.println("=== REGISTRATION ===");

        System.out.print("Enter First Name: ");
        String fName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lName = input.nextLine();

        System.out.print("Enter Username: ");
        String user = input.nextLine();

        System.out.print("Enter Password: ");
        String pass = input.nextLine();

        System.out.print("Enter Cellphone (+27...): ");
        String cell = input.nextLine();

        Account userAccount = new Account(user, pass, cell);

        String message = userAccount.registerUser();
        System.out.println(message);

        // LOGIN
        if (message.equals("User registered successfully.")) {

            System.out.println("\n=== LOGIN ===");

            System.out.print("Enter Username: ");
            String loginUser = input.nextLine();

            System.out.print("Enter Password: ");
            String loginPass = input.nextLine();

            if (loginUser.equals(userAccount.getUsername()) &&
                loginPass.equals(userAccount.getPassword()))
           
                 System.out.println("Welcome to QuickChat");
            System.out.println("""
        1. Send Messages
        2. Show Recently Sent Messages
        3. Quit
        """);

System.out.print("Choose option: ");
int option = input.nextInt();
input.nextLine();

if(option == 1)
{
    System.out.print(
            "How many messages do you want to send? ");

    int numMessages = input.nextInt();
    input.nextLine();

    for(int i = 0; i < numMessages; i++)
    {
        System.out.print("Enter Message ID: ");
        String id = input.nextLine();

        System.out.print("Enter recipient number: ");
        String recipient = input.nextLine();

        System.out.print("Enter message: ");
        String text = input.nextLine();

        if(text.length() > 250)
        {
            System.out.println(
                    "Message exceeds 250 characters");
        }

        else
        {
            Message msg =
                    new Message(id, recipient, text);

            if(!msg.checkMessageID())
            {
                System.out.println(
                        "Invalid Message ID");
            }

            else if(!msg.checkRecipientCell())
            {
                System.out.println(
                        "Invalid recipient number");
            }

            else
            {
                msg.createMessageHash();

                System.out.println(
                        msg.printMessages());

                System.out.println("""
                        1. Send Message
                        2. Disregard Message
                        3. Store Message
                        """);

                int choice = input.nextInt();
                input.nextLine();

                System.out.println(
                        msg.sentMessage(choice));
            }
        }
    }

    System.out.println(
            "Total messages sent: "
            + Message.returnTotalMessages());
}
        }
    }
}

            
        