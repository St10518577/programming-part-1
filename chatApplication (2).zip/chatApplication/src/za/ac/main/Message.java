/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package za.ac.main;

public class Message {

    private final String messageID;
    private final String recipient;
    private final String message;

    private String messageHash;

    private static int totalMessages = 0;
public static void main(String[] args){

}
    public Message(String messageID,
                   String recipient,
                   String message) {

        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
    }

    // CHECK MESSAGE ID
    public boolean checkMessageID() {

        return messageID != null && messageID.length() == 10;
    }

    // CHECK RECIPIENT CELL
    public boolean checkRecipientCell() {

        return recipient != null
                && recipient.startsWith("+")
                && recipient.length() <= 10;
    }

    // CREATE HASH
    public String createMessageHash() {

        if (message == null || message.isEmpty()) {
            return "Invalid message";
        }

        if (messageID == null || messageID.length() < 2) {
            return "Invalid message ID";
        }

        String[] words = message.trim().split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        messageHash =
                messageID.substring(0, 2)
                + ":"
                + totalMessages
                + ":"
                + firstWord.toUpperCase()
                + lastWord.toUpperCase();

        return messageHash;
    }

    // SEND MESSAGE
    public String sentMessage(int choice) {

        switch(choice) {

            case 1:
                totalMessages++;
                return "Message successfully sent.";

            case 2:
                return "Message disregarded.";

            case 3:
                return "Message stored successfully.";

            default:
                return "Invalid option.";
        }
    }

    // PRINT MESSAGE DETAILS
    public String printMessages() {

        return "Message ID: " + messageID
                + "\nRecipient: " + recipient
                + "\nMessage: " + message
                + "\nHash: " + messageHash;
    }

    // TOTAL MESSAGES
    public static int returnTotalMessages() {

        return totalMessages;
    }
}